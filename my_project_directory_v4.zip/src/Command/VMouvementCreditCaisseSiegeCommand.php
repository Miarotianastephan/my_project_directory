<?php

namespace App\Command;

use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

#[AsCommand(
    name: 'VMouvementCreditCaisse',
    description: 'Liste des mouvements de crédit en espèce ',
)]
class VMouvementCreditCaisseSiegeCommand extends Command
{
    private EntityManagerInterface  $entityManager;
    public function __construct(EntityManagerInterface $entityManager)
    {
        parent::__construct();
        $this->entityManager = $entityManager;
    }

    protected function configure(): void
    {
        /*$this
            ->addArgument('arg1', InputArgument::OPTIONAL, 'Argument description')
            ->addOption('option1', null, InputOption::VALUE_NONE, 'Option description')
        ;*/

        $this
            ->setDescription('Création de vues liste de mouvement')
            ->setHelp('Liste des mouvements de credit en caisse');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $connection = $this->entityManager->getConnection();
        $sql = 'CREATE VIEW ce_v_mouvement_credit_siege AS 
                SELECT 
                    m.mvn_id , 
                    m.mvt_evenement_id , 
                    m.mvt_compte_id ,
                    m.mvt_montant , 
                    m.is_mvt_debit , 
                    p.cpt_libelle
                FROM ce_mouvement m
                LEFT JOIN ce_plan_compte p
                ON m.mvt_compte_id = p.cpt_id 
                WHERE 
                    LOWER(p.cpt_libelle) like \'caisse si%\'  
                    AND m.is_mvt_debit = 0';
        $connection->beginTransaction();
        try {
            $stmt = $connection->prepare($sql);
            // Afficher un message d'information avant l'exécution
            $output->writeln('<info>Création de la vue VMouvementCreditCaisseSiege en cours...</info>');
            // Exécuter la requête SQL
            $stmt->executeStatement();
            $connection->commit();
            $output->writeln('<info>La vue VMouvementCreditCaisseSiege a été créée avec succès !</info>');
            return Command::SUCCESS;
        }catch (\Exception $e){
            $output->writeln('<error>' . $e->getMessage() . '</error>');
            $connection->rollback();
            return Command::FAILURE;
        }
    }
}
