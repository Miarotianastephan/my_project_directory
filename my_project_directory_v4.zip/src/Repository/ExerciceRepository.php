<?php

namespace App\Repository;

use App\Entity\Exercice;
use DateTime;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * @extends ServiceEntityRepository<Exercice>
 */
class ExerciceRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Exercice::class);
    }

    public function ajoutExercice($date_debut, $date_fin = null): JsonResponse
    {
        $entityManager = $this->getEntityManager();
        $exercice = new Exercice();

        try {
            $date_debut = new \DateTimeImmutable($date_debut);
            $exercice->setExerciceDateDebut($date_debut);
            if ($date_fin) {
                try {
                    $date_fin = new \DateTimeImmutable($date_fin);
                    $exercice->setExerciceDateFin($date_fin);
                } catch (\Exception $e) {
                    return new JsonResponse(['success' => false, 'message' => $e->getMessage()]);
                }
            }

            // Enregistrer l'exercice (vous devrez probablement appeler l'EntityManager ici)
            $entityManager->persist($exercice);
            $entityManager->flush();
            return new JsonResponse(['success' => true, 'message' => "L'exercice a été ajouté avec succès."]);
        } catch (\Exception $e) {
            $entityManager->rollback();
            return new JsonResponse(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function getExerciceNext(DateTime $date): array
    {
        return $this->createQueryBuilder('e')->where('e.exercice_date_debut > :date')->andWhere('e.exercice_date_fin IS NULL')->setParameter('date', $date, 'customdate')->getQuery()->getResult();
    }

    public function cloturerExercice(int $id_exercie,string $date_cloture): JsonResponse
    {
        $exercice_valide = $this->getExerciceValide();
        $entityManager = $this->getEntityManager();

        if (!$exercice_valide) {
            return new JsonResponse(['success' => false, 'message' => 'Aucun exercice ouvert']);
        }
        $exercice = $this->find($id_exercie);
        if (!$exercice || $exercice!= $exercice_valide){
            return new JsonResponse(['success' => false, 'message' => 'Exercice invalide']);
        }

        // Commencer une transaction
        $entityManager->beginTransaction();
        try {

            // Mettre à jour la date de fin et l'état de l'exercice
            $date_fin = new \DateTimeImmutable($date_cloture);
            $exercice->setExerciceDateFin($date_fin);
            $exercice->setValid(false);


            $entityManager->persist($exercice);
            $entityManager->flush();

            // Commit transaction
            $entityManager->commit();
            return new JsonResponse(['success' => true, 'message' => "L'exercice cloturer."]);
        } catch (\Exception $e) {
            $entityManager->rollback();
            return new JsonResponse(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function ouvertureExercice(int $id_exercie): JsonResponse
    {
        $exercice_valide = $this->getExerciceValide();
        $entityManager = $this->getEntityManager();
        if ($exercice_valide) {
            return new JsonResponse(['success' => false, 'message' => 'Fermez tous les exercice']);
        }

        $exercice = $this->find($id_exercie);
        if (!$exercice ){
            return new JsonResponse(['success' => false, 'message' => 'Exercice invalide']);
        }

        // Commencer une transaction
        $entityManager->beginTransaction();
        try {

            // Mettre à jour la date de fin et l'état de l'exercice
            $exercice->setValid(true);


            $entityManager->persist($exercice);
            $entityManager->flush();

            // Commit transaction
            $entityManager->commit();
            return new JsonResponse(['success' => true, 'message' => "L'exercice ouvert."]);
        } catch (\Exception $e) {
            $entityManager->rollback();
            return new JsonResponse(['success' => false, 'message' => $e->getMessage()]);
        }
    }




    public function getExerciceValide(): ?Exercice
    {
        return $this->createQueryBuilder('e')
            ->where('e.is_valid = true')
            ->getQuery()
            ->getOneOrNullResult();

    }

    public function findMostRecentOpenExercice(): ?Exercice
    {
        return $this->createQueryBuilder('e')->andWhere('e.exercice_date_fin IS NULL')->orderBy('e.exercice_date_debut', 'DESC')->setMaxResults(1)->getQuery()->getOneOrNullResult();
    }
}
